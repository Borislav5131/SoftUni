﻿namespace TeisterMask.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=TeisterMask;User id = sa;pwd = SoftUniserver!;";
    }
}
