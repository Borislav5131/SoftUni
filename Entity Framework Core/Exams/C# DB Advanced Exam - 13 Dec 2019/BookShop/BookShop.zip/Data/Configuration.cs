﻿namespace BookShop.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=BookShop;User id = sa;pwd = SoftUniserver! ;";
    }
}