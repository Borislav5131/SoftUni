﻿namespace _04.WildFarm.Interfaces
{
    public interface IFood
    {
        public int Quantity { get; set; }

    }
}
