﻿namespace _06.FoodShortage
{
    public interface IDentifible
    {
        public string Id { get; }
    }
}
