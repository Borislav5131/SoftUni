﻿namespace _06.FoodShortage
{
    public interface IBirthdabel
    {
        public string Birthdates { get;}
    }
}
