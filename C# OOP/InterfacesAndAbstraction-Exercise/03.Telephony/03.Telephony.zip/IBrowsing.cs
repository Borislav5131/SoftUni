﻿namespace _03.Telephony
{
    public interface IBrowsing
    {
        void Brows(string url);
    }
}
