﻿namespace _03.Telephony
{
    public interface ICalling
    {
        void Call(string number);
    }
}
