﻿namespace _04.BorderControl
{
    public interface IBirthdabel
    {
        public string Birthdates { get;}
    }
}
