﻿namespace _04.BorderControl
{
    public interface IDentifible
    {
        public string Id { get; }
    }
}
